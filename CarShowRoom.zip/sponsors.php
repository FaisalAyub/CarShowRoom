
<?php include("header.php") ?>



<div class="page-content">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle" style="background-image:url(assets/images/page_heading.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry">
                    <h1 class="text-white">Sponsors</h1>
				</div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="#">Home</a></li>
                    <li><Map></Map></li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb row END -->
        <!-- About -->
		<div class="section-full p-t50 bg-white content-inner">
            <div class="container">
				<div class="section-head text-center head-1">
					<span class="text-primary">Sponsors</span>
					<h3 class="h3 text-uppercase">Cars of the Palm beach Concours.</h3>
					<div class="dlab-separator bg-gray-dark"></div>
					<div class="col-md-12">
					
					<div class="row">
								<div class="col-md-12">
									<img src="assets/images/sponsors/Ferrari logo 1.webp" class="img-fluid center-align" />
								</div>
							</div>
							<div class="row">
								<div class="col-md-4">
									<img src="assets/images/sponsors/Seminole casion.webp" class="img-fluid center-align" />
								</div>
								<div class="col-md-4">
								<img src="assets/images/sponsors/Town of Palm Beach 1.webp" class="img-fluid center-align" />
								</div>
								<div class="col-md-4">

								</div>
							</div>
					</div>	
				
				</div>
			
            </div>
        </div>
		<!-- About End -->
		<!-- Stats -->
	
        <!-- Testimonial -->
	</div>


<style>
.center-align{
	display: block;
  margin-left: auto;
  margin-right: auto;
  width: 90%;

}
</style>


	
	<?php include("footer.php")?>