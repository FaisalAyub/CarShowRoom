
<?php include("header.php") ?>



<div class="page-content">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle" style="background-image:url(assets/images/page_heading.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry">
                    <h1 class="text-white">Map</h1>
				</div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="#">Home</a></li>
                    <li><Map></Map></li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb row END -->
        <!-- About -->
		<div class="section-full p-t50 bg-white content-inner">
            <div class="container">
				<div class="section-head text-center head-1">
					<span class="text-primary">Map</span>
					<h3 class="h3 text-uppercase">Cars of the Palm beach Concours.</h3>
					<div class="dlab-separator bg-gray-dark"></div>
					<div class="col-md-12">
						<img src="assets/images/worth avenue map.jpg" />
					</div>	
				
				</div>
			
            </div>
        </div>
		<!-- About End -->
		<!-- Stats -->
	
        <!-- Testimonial -->
	</div>
    
    
	


	<?php include("footer.php")?>